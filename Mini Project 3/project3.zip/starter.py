import turtle

turtle.setup(800, 800)
wn = turtle.Screen()

ike = turtle.Turtle()

ike.color((.20, .80, .50))

ike.forward(30)

ike.circle(50)

wn.exitonclick()
